import os
import logging
from flask import Flask, render_template, request, jsonify, session
from flask_socketio import SocketIO, emit
import threading
import time
import json
from websocket_tester import WebSocketTester

# Configure logging
logging.basicConfig(level=logging.DEBUG)

# Create Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "websocket_tester_secret_key_515")
socketio = SocketIO(app, cors_allowed_origins="*")

# Global dictionary to store active tests
active_tests = {}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/start_test', methods=['POST'])
def start_test():
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data.get('urls'):
            return jsonify({'success': False, 'message': 'يجب إدخال عنوان URL واحد على الأقل'})
        
        # Parse URLs (split by newlines)
        urls = [url.strip() for url in data['urls'].split('\n') if url.strip()]
        
        if not urls:
            return jsonify({'success': False, 'message': 'يجب إدخال عنوان URL صحيح'})
        
        # Create test configuration with enhanced WormGPT features
        config = {
            'urls': urls,
            'bots': int(data.get('bots', 100)),
            'msgs_per_bot': int(data.get('msgs_per_bot', 10)),
            'rate': float(data.get('rate', 1.0)),
            'concurrency': int(data.get('concurrency', 50)),
            'payload': data.get('payload', ''),
            'insecure_tls': data.get('insecure_tls', False),
            'corrupt_payload': data.get('corrupt_payload', False),
            'jitter': float(data.get('jitter', 0.5)),
            'bot_type': data.get('bot_type', 'default'),
            'max_attempts': int(data.get('max_attempts', 20)),
            'flood_messages': data.get('flood_messages', False),
            'open_timeout': int(data.get('open_timeout', 5)),
            'close_timeout': int(data.get('close_timeout', 3)),
            'max_backoff': float(data.get('max_backoff', 16.0))
        }
        
        # Generate test ID
        test_id = f"test_{int(time.time())}"
        
        # Create WebSocket tester
        tester = WebSocketTester(config, test_id, socketio)
        active_tests[test_id] = tester
        
        # Start test in background thread
        thread = threading.Thread(target=tester.run_test)
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'success': True, 
            'message': 'تم بدء الاختبار بنجاح',
            'test_id': test_id
        })
        
    except Exception as e:
        logging.error(f"Error starting test: {str(e)}")
        return jsonify({'success': False, 'message': f'خطأ في بدء الاختبار: {str(e)}'})

@app.route('/stop_test', methods=['POST'])
def stop_test():
    try:
        data = request.get_json()
        test_id = data.get('test_id')
        
        if test_id in active_tests:
            active_tests[test_id].stop_test()
            del active_tests[test_id]
            return jsonify({'success': True, 'message': 'تم إيقاف الاختبار'})
        else:
            return jsonify({'success': False, 'message': 'لم يتم العثور على الاختبار'})
            
    except Exception as e:
        logging.error(f"Error stopping test: {str(e)}")
        return jsonify({'success': False, 'message': f'خطأ في إيقاف الاختبار: {str(e)}'})

@socketio.on('connect')
def handle_connect():
    print('Client connected')
    emit('connected', {'message': 'تم الاتصال بنجاح'})

@socketio.on('disconnect')
def handle_disconnect():
    print('Client disconnected')

if __name__ == '__main__':
    socketio.run(app, host='0.0.0.0', port=5000, debug=True, use_reloader=False, log_output=True)
